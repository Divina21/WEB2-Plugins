<?php
/**
 * Silence is golden.
 *
 * @package           woo-gift-cards-lite
 */

// Silence is golden.
