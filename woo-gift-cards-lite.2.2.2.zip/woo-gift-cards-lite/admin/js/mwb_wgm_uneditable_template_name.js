jQuery( document ).ready(
    function($){
		$( '#poststuff' ).find( '#title' ).prop( 'readonly', true );
	}
);