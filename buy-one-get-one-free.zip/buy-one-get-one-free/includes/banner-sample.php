<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:xlink="http://www.w3.org/1999/xlink"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="182.67464mm"
   height="138.52826mm"
   viewBox="0 0 182.58765 138.52826"
   version="1.1"
   id="svg8"
   inkscape:version="0.92.4 (5da689c313, 2019-01-14)"
   sodipodi:docname="banner-sample.svg">
  <defs
     id="defs2" />
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.7"
     inkscape:cx="209.16181"
     inkscape:cy="255.28482"
     inkscape:document-units="mm"
     inkscape:current-layer="layer1"
     showgrid="false"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0"
     inkscape:showpageshadow="false"
     inkscape:window-width="1366"
     inkscape:window-height="741"
     inkscape:window-x="-9"
     inkscape:window-y="-9"
     inkscape:window-maximized="1" />
  <metadata
     id="metadata5">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Layer 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(-13.922974,-84.104927)">
    <image
       y="84.104927"
       x="13.872969"
       id="image18"
       xlink:href="<?php echo plugin_dir_url(__FILE__); ?>/background.png"
       preserveAspectRatio="none"
       height="138.52826"
       width="182.67464"
       style="fill:#12354b;fill-opacity:1" />
    <text
       xml:space="preserve"
       style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:condensed;font-size:17.17816162px;line-height:1.25;font-family:Impact;-inkscape-font-specification:'Impact, Condensed';font-variant-ligatures:normal;font-variant-caps:normal;font-variant-numeric:normal;font-feature-settings:normal;text-align:center;letter-spacing:0px;word-spacing:0px;writing-mode:lr-tb;text-anchor:middle;fill:#ff0000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="105.26713"
       y="173.76625"
       id="text839"><tspan
         sodipodi:role="line"
         id="tspan837"
         x="105.26713"
         y="173.76625"
         style="fill:#ff0000;stroke-width:0.26458335"><?php echo $date != "" ? $date : ""; ?></tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:condensed;font-size:11.21299362px;line-height:1.25;font-family:Impact;-inkscape-font-specification:'Impact, Condensed';font-variant-ligatures:normal;font-variant-caps:normal;font-variant-numeric:normal;font-feature-settings:normal;text-align:center;letter-spacing:0px;word-spacing:0px;writing-mode:lr-tb;text-anchor:middle;fill:#ffffff;fill-opacity:1;stroke:none;stroke-width:0.17270599"
       x="105.1073"
       y="187.77478"
       id="text847"><tspan
         sodipodi:role="line"
         id="tspan845"
         x="105.1073"
         y="187.77478"
         style="fill:#ffffff;stroke-width:0.17270599">USE COUPON CODE</tspan></text>
    <text
       xml:space="preserve"
       style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:condensed;font-size:17.17816162px;line-height:1.25;font-family:Impact;-inkscape-font-specification:'Impact, Condensed';font-variant-ligatures:normal;font-variant-caps:normal;font-variant-numeric:normal;font-feature-settings:normal;text-align:center;letter-spacing:0px;word-spacing:0px;writing-mode:lr-tb;text-anchor:middle;fill:#ff0000;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="105.12034"
       y="205.89409"
       id="text851"><tspan
         sodipodi:role="line"
         id="tspan849"
         x="105.12034"
         y="205.89409"
         style="fill:#ff0000;stroke-width:0.26458335"><?php echo $coupon_code != "" ? $coupon_code : ""; ?></tspan></text>
    <g
       id="g865"
       transform="matrix(0.88533135,0,0,0.88533135,9.793326,11.769822)">
      <text
         id="text855"
         y="142.37138"
         x="70.503731"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:condensed;font-size:50.79443359px;line-height:1.25;font-family:Impact;-inkscape-font-specification:'Impact, Condensed';font-variant-ligatures:normal;font-variant-caps:normal;font-variant-numeric:normal;font-feature-settings:normal;text-align:center;letter-spacing:0px;word-spacing:0px;writing-mode:lr-tb;text-anchor:middle;fill:#ff0000;fill-opacity:1;stroke:none;stroke-width:0.78235155"
         xml:space="preserve"><tspan
           style="fill:#ff0000;stroke-width:0.78235155"
           y="142.37138"
           x="70.503731"
           id="tspan853"
           sodipodi:role="line"><?php echo $percent != "" ? $percent : ""; ?></tspan></text>
      <text
         id="text859"
         y="141.56055"
         x="140.19904"
         style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:condensed;font-size:51.13373566px;line-height:1.25;font-family:Impact;-inkscape-font-specification:'Impact, Condensed';font-variant-ligatures:normal;font-variant-caps:normal;font-variant-numeric:normal;font-feature-settings:normal;text-align:center;letter-spacing:0px;word-spacing:0px;writing-mode:lr-tb;text-anchor:middle;fill:#ffffff;fill-opacity:1;stroke:none;stroke-width:0.78757757"
         xml:space="preserve"><tspan
           style="fill:#ffffff;stroke-width:0.78757757"
           y="141.56055"
           x="140.19904"
           id="tspan857"
           sodipodi:role="line">OFF</tspan></text>
    </g>
    <text
       xml:space="preserve"
       style="font-style:normal;font-variant:normal;font-weight:normal;font-stretch:condensed;font-size:17.17816162px;line-height:1.25;font-family:Impact;-inkscape-font-specification:'Impact, Condensed';font-variant-ligatures:normal;font-variant-caps:normal;font-variant-numeric:normal;font-feature-settings:normal;text-align:center;letter-spacing:0px;word-spacing:0px;writing-mode:lr-tb;text-anchor:middle;fill:#ffffff;fill-opacity:1;stroke:none;stroke-width:0.26458335"
       x="104.97174"
       y="155.73141"
       id="text846"><tspan
         sodipodi:role="line"
         id="tspan844"
         x="104.97174"
         y="155.73141"
         style="fill:#ffffff;stroke-width:0.26458335"><?php echo $tagline != "" ? $tagline : ""; ?></tspan></text>
    <g
       data-name="Layer 2"
       id="Layer_2"
       transform="matrix(0.26458335,0,0,0.26458335,19.905052,198.62325)">
      <g
         data-name="Layer 1"
         id="Layer_1-2">
        <path
           id="path828"
           d="m 140.413,0.005 c 0,0 20.1,-0.8 12.2,17.7 l -12.875,30.163 c 0,0 -7.9,18.5 -27.9,16.3 L 13.621,53.354 c 0,0 -11.927,-1.314 -12.691,-13.29 L 0.016,25.739 c 0,0 -1.281,-20.078 18.822,-20.88 z"
           inkscape:connector-curvature="0"
           style="fill:#e8308a" />
        <path
           id="path830"
           d="m 32.167,21.564 a 4.038,4.038 0 0 1 1.738,3.448 4.125,4.125 0 0 1 -3.287,4.177 4.861,4.861 0 0 1 2.95,1.616 4.731,4.731 0 0 1 1.065,3.152 4.487,4.487 0 0 1 -1.873,3.813 8.4,8.4 0 0 1 -5.106,1.387 H 19.033 V 20.3 h 8.379 a 7.921,7.921 0 0 1 4.755,1.264 z m -2.748,5.819 a 2.062,2.062 0 0 0 0.795,-1.725 1.964,1.964 0 0 0 -0.795,-1.67 3.488,3.488 0 0 0 -2.2,-0.566 h -4.58 V 28 h 4.58 a 3.49,3.49 0 0 0 2.2,-0.617 z m 0.5,8 a 2.164,2.164 0 0 0 0.971,-1.886 2.084,2.084 0 0 0 -0.971,-1.818 4.6,4.6 0 0 0 -2.694,-0.634 h -4.58 v 4.985 h 4.58 a 4.537,4.537 0 0 0 2.692,-0.645 z"
           inkscape:connector-curvature="0"
           style="fill:#ffffff" />
        <path
           id="path832"
           d="m 51.311,24.742 v 14.415 h -3.53 V 36.49 a 5.174,5.174 0 0 1 -5.011,2.8 5.01,5.01 0 0 1 -3.826,-1.482 5.642,5.642 0 0 1 -1.4,-4.041 v -9.025 h 3.529 v 8 a 3.291,3.291 0 0 0 0.822,2.37 2.992,2.992 0 0 0 2.277,0.863 3.335,3.335 0 0 0 2.64,-1.186 4.413,4.413 0 0 0 0.97,-2.936 v -7.111 z"
           inkscape:connector-curvature="0"
           style="fill:#ffffff" />
        <path
           id="path834"
           d="m 59.919,43.644 a 4.962,4.962 0 0 1 -2.977,0.9 5.5,5.5 0 0 1 -1.9,-0.31 6,6 0 0 1 -1.684,-0.983 l 1.509,-2.668 a 4.438,4.438 0 0 0 0.944,0.553 2.42,2.42 0 0 0 0.916,0.175 2.21,2.21 0 0 0 2.1,-1.455 l 0.431,-0.943 -5.953,-14.171 h 3.637 l 4.095,10.482 3.746,-10.482 h 3.529 l -6.466,16.221 a 5.671,5.671 0 0 1 -1.927,2.681 z"
           inkscape:connector-curvature="0"
           style="fill:#ffffff" />
        <path
           id="path836"
           d="m 89.516,26.1 a 5.625,5.625 0 0 1 1.428,4.054 v 9 h -3.529 v -7.972 a 3.249,3.249 0 0 0 -0.863,-2.384 3.139,3.139 0 0 0 -2.344,-0.876 3.551,3.551 0 0 0 -2.762,1.186 4.346,4.346 0 0 0 -1.01,2.963 v 7.086 h -3.5 V 24.742 h 3.5 v 2.7 a 5.461,5.461 0 0 1 5.173,-2.829 5.146,5.146 0 0 1 3.907,1.487 z"
           inkscape:connector-curvature="0"
           style="fill:#ffffff" />
        <path
           id="path838"
           d="m 105.129,25.551 a 6.636,6.636 0 0 1 2.668,2.573 7.5,7.5 0 0 1 0.956,3.813 7.617,7.617 0 0 1 -0.956,3.852 6.606,6.606 0 0 1 -2.668,2.587 8.243,8.243 0 0 1 -3.947,0.916 8.384,8.384 0 0 1 -3.988,-0.916 6.568,6.568 0 0 1 -2.68,-2.587 7.6,7.6 0 0 1 -0.957,-3.852 7.477,7.477 0 0 1 0.957,-3.813 6.6,6.6 0 0 1 2.68,-2.573 8.384,8.384 0 0 1 3.988,-0.916 8.243,8.243 0 0 1 3.947,0.916 z m -6.911,3.287 a 4.437,4.437 0 0 0 -1.132,3.152 4.44,4.44 0 0 0 1.132,3.153 3.868,3.868 0 0 0 2.964,1.213 3.8,3.8 0 0 0 2.91,-1.213 4.44,4.44 0 0 0 1.132,-3.153 4.437,4.437 0 0 0 -1.132,-3.152 3.8,3.8 0 0 0 -2.91,-1.213 3.864,3.864 0 0 0 -2.964,1.213 z"
           inkscape:connector-curvature="0"
           style="fill:#ffffff" />
        <path
           id="path840"
           d="m 109.076,24.77 3.61,-0.028 3.53,10.886 3.422,-10.886 h 3.529 l 3.476,10.886 3.449,-10.886 h 3.53 l -5.228,14.415 h -3.583 L 121.362,29 117.94,39.157 h -3.583 z"
           inkscape:connector-curvature="0"
           style="fill:#ffffff" />
      </g>
    </g>
  </g>
</svg>
