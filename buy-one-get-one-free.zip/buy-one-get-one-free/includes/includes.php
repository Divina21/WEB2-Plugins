<?php
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/pisol.class.form.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/pisol.class.promotion.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/review.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-buy-one-get-one-free-woocommerce-admin-menu.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-buy-one-get-one-free-woocommerce-option.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-buy-one-get-one-free-woocommerce-category.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-buy-one-get-one-free-woocommerce-cat-message.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-buy-one-get-one-free-woocommerce-product.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-bogo-cart.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-bogo-parent.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-bogo-free-product.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-bogo-rule.php';
require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-woo.php';
