<h2>Difference between the 3 rules</h2>

<div class="row">
<div class="col-12 col-md-6 my-3">
<div class="card">
<h3>Buy product A and get product B Free</h3>
<p>E.g: Category A has product --> B, C<br>

Free product --> D <br>
Free unit --> 1<br>
Max limit --> 2<br>

2 x B he will get 2 unit of D<br>
3 x C he will get 2 unit of D </p>
</div>
</div>
<div class="col-12 col-md-6 my-3">
<div class="card">
<h3>Buy product A and get product A Free</h3>
<p>
E.g: Category A has product --> B, C<br>
 
Free unit --> 1<br>
Max limit --> 2<br>

2 x B he will get 2 unit of B<br>
3 x C he will get 2 unit of C<br>
</p>
</div>
</div>
<div class="col-12 col-md-12 my-3">
<div class="card">
<h3>Buy product from  category get product B Free</h3>
<p>
E.g: Category A has product --> B, C<br>

Free product --> D <br>
Free unit --> 1<br>
Max limit --> 3<br>

2 x B he will get 2 unit of D<br>
3 x C he will get 1 unit of D<br>
</p>
</div>
</div>

</div>

