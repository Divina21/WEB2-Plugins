=== Remove Add to Cart WooCommerce ===
Contributors: themelocation
Donate link: https://www.paypal.me/themelocation
Tags: WooCommerce, add to cart, remove cart button, remove cart
Requires at least: 4.5
Tested up to: 5.6.0
Stable Tag: 1.4.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


How to Remove/disable Add to cart And Replace Cart button with Inquiry Us button in WooCommerce.

== Description ==

This Plugin performs following functions; Developed by <a href="https://www.themelocation.com/">themelocation</a>

1- Remove/Disable Add to Cart from Complete WooCommerce Shop.<br>
2- Replace Add to Cart button with Inquire Us from Complete Category.<br>
3- Remove Add to cart from individual Product pages.<br>
4- Replace Add to cart with Inquire us from product pages.<br>
5- Hide price from Complete Category<br>
6- Hide Price per Product<br>

<p>You can Buy Paid Version <a href="https://www.themelocation.com/remove-cart-button-plugin/">Here</a></p>

<p><iframe width="560" height="315" src="https://www.youtube.com/embed/hCFf3yr_DRI" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe></p>

This Plugin Work on both Category Level as well as Individual Level. If Store owner do not want add to cart button on Whole category, He can remove that.

If Store Owner wants to remove add to cart from Specific product, he can do that.

Also, If Someone want to replace add to cart with inquiry button he can do that too with this Plugin. 

You can make settings on Category pages and individual Product pages.


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3- Under each product you will see option to configure the plugin.

== Upgrade Notice ==

New Features Added.

<ul>
<li>Hide Product Price</li>
<li>Hide All Category Products Price </li>
<li>Change "Inquire us" Text</li>
</ul>

If You need any Help Simple <a href="http://themelocation.com/contact/">Contact us</a>
