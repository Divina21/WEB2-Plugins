<?php

/**
 * @package  hostpluginWoocommercePointsRewards
 */

namespace HPWooRewardsIncludes;

class Deactivation {

	/**
	 *
	 * call when de-activate is clicked
	 *
	 * @since 1.0
	 * @return void
	 *
	 */
	public static function deactivate() {
		
	}
}